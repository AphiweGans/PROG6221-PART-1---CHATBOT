﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CyberAware
{
    public class ResponseHandler
    {
        // Core topics dictionary (kept as before, extended with a few additional keys)
        private readonly Dictionary<string, string> topics = new()
        {
            { "password", "Strong passwords are your first line of defense. Use a long, unique passphrase for each account, combine upper and lower case letters, numbers and symbols, and avoid dictionary words or obvious substitutions. Consider using a reputable password manager to generate and store complex passwords safely, and enable two-factor authentication where available to add an extra layer of protection." },
            { "phishing", "Phishing is a cyberattack where criminals trick you into revealing sensitive information by impersonating trusted organizations. Phishing can arrive by email, text, or spoofed websites. Look for signs like unexpected requests for credentials, poor spelling or grammar, mismatched URLs, and urgent language. Always verify senders, avoid clicking links in unsolicited messages, and use multi-factor authentication to limit the damage of credential theft." },
            { "safe browsing", "Safe browsing means being cautious online to reduce exposure to threats. Use up-to-date browsers, keep extensions to a minimum, and avoid downloading files from unknown sources. Check site certificates on sensitive pages, prefer HTTPS, and be careful when entering personal information. Use privacy settings, ad-blockers if appropriate, and enable security features like site isolation to reduce risk." },
            { "malware", "Malware is malicious software designed to damage, steal, or control systems. It includes viruses, worms, trojans, ransomware, spyware, and more. Prevent malware by keeping software updated, running reputable antivirus or endpoint protection, avoiding dubious downloads and attachments, and applying the principle of least privilege. Back up important data regularly to recover from attacks like ransomware." },
            { "identity theft", "Identity theft occurs when criminals steal personal information to impersonate you, access accounts, or commit fraud. Protect yourself by monitoring credit reports, using strong unique passwords, enabling two-factor authentication, shredding sensitive documents, and being cautious about sharing personal data online. If you suspect theft, contact banks and credit agencies immediately and consider a fraud alert or freeze on your credit." },
            { "social media", "Social media can expose you to risks if you overshare personal information, accept unknown friend requests, or click on suspicious links. Adjust privacy settings to limit who can see your posts, avoid posting sensitive details like vacation dates or addresses, and be mindful of phishing attempts that come through messages. Use strong account security and review connected apps regularly." },
            { "two factor", "Two-factor authentication (2FA) adds an extra layer of security by requiring a second verification step beyond a password, such as a code from an authenticator app or a hardware token. 2FA greatly reduces the risk of account takeover even if passwords are compromised. Prefer authenticator apps or hardware keys over SMS where possible, because SMS can be intercepted." },
            { "updates", "Software updates are critical for security because they often include patches for vulnerabilities that attackers can exploit. Keep your operating system, applications, and firmware up to date. Enable automatic updates when practical, and test updates in critical environments to avoid disruptions. Regular patching is one of the most effective ways to reduce risk." },
            { "wifi", "Public Wi-Fi networks are convenient but often insecure; attackers may intercept traffic on open hotspots. Avoid accessing sensitive sites on public Wi-Fi, or use a trusted VPN to encrypt your connection. Ensure your home Wi-Fi uses a strong WPA2/WPA3 password and consider hiding the SSID or using a guest network for visitors." },
            { "privacy", "Privacy means controlling how your personal information is collected and shared online. Limit data sharing, review app and social media permissions, use strong account controls, and prefer services with clear privacy practices. Consider using privacy-enhancing tools like tracker blockers and private browsing modes." },
            { "virus", "A computer virus is a type of malware that attaches to legitimate programs and propagates when those programs run. Modern threats are diverse, including ransomware and trojans that don’t behave like traditional viruses. Use layered defenses: keep software patched, run endpoint protection, avoid suspicious attachments, and back up data so you can recover from infection." },
            { "purpose", "My purpose is to increase people’s knowledge and understanding about cybersecurity, helping you stay safe online. I provide practical tips, explain common threats, and suggest steps you can take to reduce risk. If you have specific scenarios or concerns, ask and I’ll give actionable guidance tailored to your situation." },
            { "how are you", "I’m doing well — thank you for asking! I’m here to help you learn about cybersecurity and answer questions. Tell me a topic you’d like to explore and I’ll provide guidance, examples, and resources to help you stay safe online." },
            { "what can i ask", "You can ask me about cybersecurity topics such as passwords, phishing, malware, safe browsing, scams, identity theft, social media safety, two-factor authentication, software updates, public Wi-Fi, computer viruses, and also practical steps for securing personal devices and accounts. If you have a real-world scenario, describe it and I’ll help you analyze risks and protections." }
            ,
            { "scam", "Scams are fraudulent schemes designed to trick people into sending money, revealing personal information, or installing malicious software. Common signs include unexpected requests for payment or gift cards, pressure to act quickly, unsolicited contact, and requests for personal or financial information. Verify requests via independent channels, never send money to unknown parties, and report scams to the platform or authorities." },
            { "ransomware", "Definition: Ransomware is malicious software that encrypts data or locks systems and demands a ransom to restore access. Explanation: It spreads via phishing, exploit kits, or unsecured remote access and can target individuals and organizations, often encrypting backups to maximize impact. Solution: Maintain offline, tested backups; keep systems patched; use endpoint protection; employ least-privilege access; segment networks; and train users to recognise phishing attempts." },
            { "ddos", "Definition: A DDoS (Distributed Denial of Service) attack overwhelms a target service with excessive traffic to make it unavailable. Explanation: Attackers use botnets or reflected amplification to flood bandwidth or exhaust resources, causing outages and degraded performance. Solution: Use rate-limiting, upstream DDoS protection, CDN services, traffic filtering, redundant infrastructure, and incident response plans to mitigate and recover from attacks." },
            { "zero-day", "Definition: A zero-day vulnerability is a software flaw unknown to the vendor and exploitable by attackers before a patch is available. Explanation: Because no fix exists initially, attackers can weaponize zero-days for high-impact breaches or espionage. Solution: Employ defense-in-depth: timely threat monitoring, behavior-based detection, application whitelisting, network segmentation, rapid patching once advisories publish, and vendor mitigation workarounds when available." },
            { "encryption", "Definition: Encryption converts data into a coded form to prevent unauthorized access. Explanation: Proper encryption protects data at rest and in transit from interception or theft; key management and algorithm choice are critical. Solution: Use strong, modern algorithms (AES-256, TLS 1.2+/TLS 1.3), protect keys with hardware security modules or secure vaults, enforce encryption for backups and communications, and rotate keys per policy." },
            { "insider threat", "Definition: An insider threat occurs when a current or former employee, contractor, or partner intentionally or accidentally causes harm or data loss. Explanation: Risks include data exfiltration, careless credential handling, or abuse of privileges. Solution: Implement least-privilege access, monitor user activity, enforce separation of duties, use data loss prevention (DLP), conduct background checks, and provide regular security awareness training." },
            { "supply chain", "Definition: A supply chain attack targets software or hardware vendors to compromise downstream customers. Explanation: Attackers compromise updates, third-party libraries, or vendor systems to distribute malware or backdoors at scale. Solution: Vet vendors, apply integrity checks (signatures/hashes), monitor for unusual behavior, use dependency scanning, and keep critical systems isolated and monitored." },
            { "iot security", "Definition: IoT security covers protecting internet-connected devices like cameras, sensors, and appliances. Explanation: Many IoT devices are resource constrained and shipped with weak defaults, making them attractive targets for compromise and botnet recruitment. Solution: Change default credentials, keep firmware updated, segment IoT networks, disable unnecessary services, and choose devices from vendors with security practices and update policies." },
            { "cloud security", "Definition: Cloud security involves protecting data, applications, and services hosted in cloud environments. Explanation: Misconfigurations, excessive permissions, and insecure APIs are common cloud risks that can lead to data exposure. Solution: Use strong identity and access management (IAM), enable logging and monitoring, encrypt data, apply the principle of least privilege, automate configuration checks, and follow provider security best practices." }
        };

        // Randomized tip pools to keep responses varied and engaging
        private readonly List<string> phishingTips = new()
        {
            "Tip: Always verify the sender's email address and hover over links to see the real destination before clicking.",
            "Tip: Be wary of urgent or threatening language asking you to act immediately—scammers use pressure to force mistakes.",
            "Tip: Never provide credentials or sensitive data in response to unsolicited messages; use official channels to verify requests.",
            "Tip: Check for mismatched domain names or subtle typos in URLs—attackers often create convincing look-alikes."
        };

        private readonly List<string> passwordTips = new()
        {
            "Use a long passphrase made of multiple unrelated words rather than a single word.",
            "Consider a reputable password manager to create and store unique passwords for every account.",
            "Enable two-factor authentication (2FA) wherever possible to add an extra layer of protection.",
            "Avoid reusing passwords across important accounts; compromise on one site can cascade elsewhere."
        };

        // Privacy-focused tips to respond when the user asks about privacy
        private readonly List<string> privacyTips = new()
        {
            "Tip: Review and tighten privacy settings on social platforms; limit who can see your posts and profile details.",
            "Tip: Be cautious sharing personal details online (birthdate, address, phone); attackers can use this for identity theft.",
            "Tip: Use browser privacy features (block third-party cookies, enable tracking protection) and consider privacy-focused extensions.",
            "Tip: Regularly review app permissions on your devices and revoke access that isn’t necessary."
        };

        private readonly List<string> scamTips = new()
        {
            "If someone asks for money or gift cards unexpectedly, pause and verify via an independent channel.",
            "Report scams to the appropriate platform or authority; reporting helps protect others.",
            "Don't trust messages asking for personal or financial information—contact the organisation directly using known contact details."
        };

        // Random instance used to pick random tips from tip pools.
        // The System.Random class provides pseudo-random numbers; here we use
        // rng.Next(pool.Count) to choose an index into a List<string> of tips.
        // This keeps responses varied so users don't always get the same tip.
        private readonly Random rng = new();

        // General tips to use when the user expresses emotion but no specific topic is mentioned
        private readonly List<string> generalTips = new()
        {
            "Quick tip: If you're unsure about messages, don't click links or download attachments until you verify the sender.",
            "Quick tip: Use unique passwords and enable two-factor authentication to reduce the chance of account takeover.",
            "Quick tip: Keep backups of important files and ensure your system and applications are up to date.",
            "Quick tip: If you feel overwhelmed, take a short break and tackle one security step at a time (e.g., enable 2FA on your main email)."
        };

        // Simple per-user session memory to support follow-ups and personalization
        private class UserSession
        {
            public string? LastTopic { get; set; }
            public int TipIndex { get; set; }
            public string? FavoriteTopic { get; set; }
            public string? Sentiment { get; set; }
        }

        private static readonly Dictionary<string, UserSession> sessions = new(StringComparer.OrdinalIgnoreCase);

        // Sentiment detection delegate and event so UI can react (empathetic messages / UI changes)
        public delegate void SentimentDelegate(string userName, string sentiment, string originalInput);
        public event SentimentDelegate? SentimentDetected;

        // Favorite topic delegate and event so UI can react when a user sets a favourite
        public delegate void FavoriteDelegate(string userName, string favouriteTopic);
        public event FavoriteDelegate? FavoriteUpdated;

        // Expose some session info for the UI to query (read-only)
        public string? GetFavoriteTopic(string userName)
        {
            if (string.IsNullOrWhiteSpace(userName)) return null;
            if (sessions.TryGetValue(userName, out var s)) return s.FavoriteTopic;
            return null;
        }

        public string? GetLastTopic(string userName)
        {
            if (string.IsNullOrWhiteSpace(userName)) return null;
            if (sessions.TryGetValue(userName, out var s)) return s.LastTopic;
            return null;
        }

        public string? GetSentiment(string userName)
        {
            if (string.IsNullOrWhiteSpace(userName)) return null;
            if (sessions.TryGetValue(userName, out var s)) return s.Sentiment;
            return null;
        }

        public string GetResponse(string input, string userName)
        {
            input = input.ToLower();

            // Ensure a session exists
            lock (sessions)
            {
                if (!sessions.ContainsKey(userName))
                    sessions[userName] = new UserSession();
            }

            var session = sessions[userName];

            // Basic sentiment detection: map keywords to simple sentiment labels
            var sentiment = DetectSentiment(input);
            if (sentiment != null)
            {
                session.Sentiment = sentiment;
                // Notify any subscribers (UI) about the sentiment so they can adjust tone/appearance
                try { SentimentDetected?.Invoke(userName, sentiment, input); } catch { }
                // If sentiment is detected but no explicit topic was found in the same input,
                // respond empathetically and give an immediate, simple cybersecurity tip.
                // This ensures the bot acknowledges the user's feelings and provides actionable help.
                bool containsAnyTopic = topics.Keys.Any(k => !string.IsNullOrWhiteSpace(k) && input.Contains(k, StringComparison.OrdinalIgnoreCase));
                if (!containsAnyTopic)
                {
                    // Use a simple switch to adjust tone based on sentiment and provide an encouraging tip.
                    string empathyPrefix;
                    string tip;
                    switch (sentiment)
                    {
                        case "worried":
                            empathyPrefix = "I can sense you're feeling worried — that's completely understandable.";
                            tip = session.FavoriteTopic != null && topics.ContainsKey(session.FavoriteTopic)
                                ? topics[session.FavoriteTopic]
                                : generalTips[rng.Next(generalTips.Count)];
                            break;
                        case "frustrated":
                            empathyPrefix = "I'm sorry you're feeling frustrated. Take a breath — small steps can help.";
                            tip = session.FavoriteTopic != null && topics.ContainsKey(session.FavoriteTopic)
                                ? topics[session.FavoriteTopic]
                                : generalTips[rng.Next(generalTips.Count)];
                            break;
                        case "curious":
                            empathyPrefix = "Great — curiosity is the first step to learning more.";
                            tip = session.FavoriteTopic != null && topics.ContainsKey(session.FavoriteTopic)
                                ? topics[session.FavoriteTopic]
                                : generalTips[rng.Next(generalTips.Count)];
                            break;
                        case "confused":
                            empathyPrefix = "I understand this can be confusing — I'm here to help and explain things step by step.";
                            tip = session.FavoriteTopic != null && topics.ContainsKey(session.FavoriteTopic)
                                ? topics[session.FavoriteTopic]
                                : generalTips[rng.Next(generalTips.Count)];
                            break;
                        default:
                            empathyPrefix = "Thanks for sharing how you feel. I can help with some quick steps.";
                            tip = generalTips[rng.Next(generalTips.Count)];
                            break;
                    }

                    return Personalize(userName, empathyPrefix + " " + tip);
                }
            }

            // If a sentiment word and a topic both appear in the same sentence, prefer to
            // provide the topic explanation while still notifying the UI about sentiment.
            // This explicitly checks for topic keywords (word-boundary tolerant) early so
            // inputs like "I'm worried about scams." trigger both behaviors.
            // Before we match topics, check whether the user is explicitly stating a favourite topic
            // such as "my favourite topic is phishing" or "I like passwords". If so, record it
            // and set LastTopic so the UI will display it the same way as other topic selections.
            try
            {
                var favEarly = TryExtractFavoriteTopic(input);
                if (!string.IsNullOrEmpty(favEarly))
                {
                    session.FavoriteTopic = favEarly;
                    session.LastTopic = favEarly;
                    try { FavoriteUpdated?.Invoke(userName, favEarly); } catch { }
                    return Personalize(userName, $"Thanks — I’ll remember that your favourite topic is '{favEarly}'. I can share more about it anytime.");
                }
            }
            catch { }

            try
            {
                var matched = topics.Keys.Where(k => !string.IsNullOrWhiteSpace(k) && input.Contains(k, StringComparison.OrdinalIgnoreCase)).ToList();
                if (matched.Count > 0)
                {
                    var topicKey = matched.First();
                    session.LastTopic = topicKey;
                    if (string.Equals(topicKey, "phishing", StringComparison.OrdinalIgnoreCase))
                        return Personalize(userName, GetRandomFromPool(phishingTips, userName));
                    if (string.Equals(topicKey, "password", StringComparison.OrdinalIgnoreCase))
                        return Personalize(userName, GetRandomFromPool(passwordTips, userName));
                    if (string.Equals(topicKey, "privacy", StringComparison.OrdinalIgnoreCase))
                        return Personalize(userName, GetRandomFromPool(privacyTips, userName));
                    if (string.Equals(topicKey, "scam", StringComparison.OrdinalIgnoreCase))
                        return Personalize(userName, GetRandomFromPool(scamTips, userName));

                    return Personalize(userName, topics[topicKey]);
                }
            }
            catch { }

            // If the user entered a number (e.g. from the help menu), map it to the topic by index.
            var trimmed = input.Trim();
            if (int.TryParse(trimmed, out var idx))
            {
                if (idx >= 1 && idx <= topics.Count)
                {
                    var topicKey = topics.Keys.ElementAt(idx - 1);
                    session.LastTopic = topicKey;
                    return Personalize(userName, topics[topicKey]);
                }
            }

            var synonyms = new Dictionary<string, string>
            {
                // removed mapping to "scam" so fraud/con won't resolve to a removed topic
                { "hackers", "malware" }, { "hacker", "malware" },
                { "spyware", "malware" }, { "trojan", "malware" },
                { "identity", "identity theft" }, { "social", "social media" },
                { "2fa", "two factor" }, { "authentication", "two factor" },
                { "update", "updates" }, { "patch", "updates" },
                { "internet", "wifi" }, { "network", "wifi" }
            };

            foreach (var kvp in synonyms)
            {
                if (input.Contains(kvp.Key))
                {
                    session.LastTopic = kvp.Value;
                    return Personalize(userName, topics[kvp.Value]);
                }
            }

            // Handle follow-up requests (e.g., "give me another tip", "tell me more", "explain more")
            if (IsFollowUpRequest(input) && !string.IsNullOrWhiteSpace(session.LastTopic))
            {
                return Personalize(userName, GetFollowUpForTopic(session.LastTopic, userName));
            }

            foreach (var topic in topics.Keys)
            {
                int distance = LevenshteinDistance(input, topic);
                if (distance > 0 && distance <= 2)
                {
                    // In GUI we avoid console prompts; assume suggestion and provide helpful response
                    session.LastTopic = topic;
                    return Personalize(userName, $"I think you meant '{topic}'. {topics[topic]}");
                }

                foreach (var word in input.Split(' '))
                {
                    int wordDistance = LevenshteinDistance(word, topic);
                    if (wordDistance > 0 && wordDistance <= 2)
                    {
                        session.LastTopic = topic;
                        return Personalize(userName, $"I think you meant '{topic}'. {topics[topic]}");
                    }
                }
            }

            foreach (var kvp in topics)
            {
                if (input.Contains(kvp.Key))
                {
                    // remember the active topic for follow-ups
                    session.LastTopic = kvp.Key;
                    // Special handling for certain topics to provide randomised tips
                    if (kvp.Key == "phishing")
                        return Personalize(userName, GetRandomFromPool(phishingTips, userName));
                    if (kvp.Key == "password")
                        return Personalize(userName, GetRandomFromPool(passwordTips, userName));
                    if (kvp.Key == "privacy")
                        return Personalize(userName, GetRandomFromPool(privacyTips, userName));
                    if (kvp.Key == "scam")
                        return Personalize(userName, GetRandomFromPool(scamTips, userName));

                    return Personalize(userName, kvp.Value);
                }
            }

            if (input.Contains("help"))
            {
                // Creative, cyan-colored menu with perfectly aligned frame
                Console.ForegroundColor = ConsoleColor.Cyan;
                int innerWidth = 58;
                Console.WriteLine("╔" + new string('═', innerWidth) + "╗");
                string header = "📚 Topics you can ask me about (type a topic or number)";
                // center the header within the inner width
                string headerCentered = header.PadLeft((innerWidth + header.Length) / 2).PadRight(innerWidth);
                Console.WriteLine("║" + headerCentered + "║");
                Console.WriteLine("╠" + new string('═', innerWidth) + "╣");
                int i = 1;
                foreach (var topic in topics.Keys)
                {
                    Console.WriteLine($"║  {i.ToString().PadLeft(2)}. {topic.PadRight(52)}║");
                    i++;
                }
                Console.WriteLine("╚" + new string('═', innerWidth) + "╝");
                Console.ResetColor();
                return Personalize(userName, "Type one of these topics to learn more!");
            }

            // Capturing simple user-stated preferences, e.g. "my favourite topic is phishing" or "i like passwords"
            var fav = TryExtractFavoriteTopic(input);
            if (!string.IsNullOrEmpty(fav))
            {
                session.FavoriteTopic = fav;
                return Personalize(userName, $"Thanks — I’ll remember that your favourite topic is '{fav}'. I can share more about it anytime.");
            }

            return Personalize(userName, "I didn’t quite understand that. Could you rephrase or try asking about password, scam, phishing or privacy?");
        }

        private string? DetectSentiment(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return null;
            input = input.ToLowerInvariant();
            if (input.Contains("worri") || input.Contains("scared") || input.Contains("anxious") || input.Contains("nerv")) return "worried";
            if (input.Contains("curious") || input.Contains("wonder") || input.Contains("like to know")) return "curious";
            if (input.Contains("frustrat") || input.Contains("annoy") || input.Contains("angry")) return "frustrated";
            if (input.Contains("confus") || input.Contains("don’t understand") || input.Contains("dont understand")) return "confused";
            return null;
        }

        private bool IsFollowUpRequest(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return false;
            input = input.ToLowerInvariant();
            return input.Contains("another tip") || input.Contains("give me another tip") || input.Contains("tell me more") || input.Contains("explain more") || input.Equals("more") || input.Contains("explain");
        }

        private string GetFollowUpForTopic(string topic, string userName)
        {
            var session = sessions[userName];
            if (string.Equals(topic, "phishing", StringComparison.OrdinalIgnoreCase))
            {
                // cycle through tips to avoid repetition
                session.TipIndex = (session.TipIndex + 1) % Math.Max(1, phishingTips.Count);
                return GetRandomFromPool(phishingTips, userName);
            }
            if (string.Equals(topic, "password", StringComparison.OrdinalIgnoreCase))
            {
                session.TipIndex = (session.TipIndex + 1) % Math.Max(1, passwordTips.Count);
                return GetRandomFromPool(passwordTips, userName);
            }
            if (string.Equals(topic, "privacy", StringComparison.OrdinalIgnoreCase))
            {
                session.TipIndex = (session.TipIndex + 1) % Math.Max(1, privacyTips.Count);
                return GetRandomFromPool(privacyTips, userName);
            }
            if (string.Equals(topic, "scam", StringComparison.OrdinalIgnoreCase))
            {
                session.TipIndex = (session.TipIndex + 1) % Math.Max(1, scamTips.Count);
                return GetRandomFromPool(scamTips, userName);
            }
            // default: return the long-form topic explanation again
            return topics.ContainsKey(topic) ? topics[topic] : "I can share more, tell me what you'd like to know about this topic.";
        }

        private string GetRandomFromPool(List<string> pool, string userName)
        {
            if (pool == null || pool.Count == 0) return string.Empty;
            // small attempt to reduce exact repetition using session index
            var session = sessions[userName];
            int idx = rng.Next(pool.Count);
            // if TipIndex set use that to select predictable next element
            if (session.TipIndex >= 0 && session.TipIndex < pool.Count)
            {
                idx = session.TipIndex;
            }
            // rotate index for next time
            session.TipIndex = (idx + 1) % pool.Count;
            return pool[idx];
        }

        private string? TryExtractFavoriteTopic(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return null;
            // look for patterns like "my favourite topic is phishing" or "i like passwords"
            input = input.ToLowerInvariant();
            if (input.Contains("favourite") || input.Contains("favorite") || input.Contains("i like") || input.Contains("my favourite") || input.Contains("my favorite"))
            {
                foreach (var t in topics.Keys)
                {
                    if (input.Contains(t)) return t;
                }
            }
            return null;
        }

        private int LevenshteinDistance(string a, string b)
        {
            int[,] dp = new int[a.Length + 1, b.Length + 1];
            for (int i = 0; i <= a.Length; i++) dp[i, 0] = i;
            for (int j = 0; j <= b.Length; j++) dp[0, j] = j;

            for (int i = 1; i <= a.Length; i++)
            {
                for (int j = 1; j <= b.Length; j++)
                {
                    int cost = (a[i - 1] == b[j - 1]) ? 0 : 1;
                    dp[i, j] = Math.Min(Math.Min(dp[i - 1, j] + 1, dp[i, j - 1] + 1),
                                        dp[i - 1, j - 1] + cost);
                }
            }
            return dp[a.Length, b.Length];
        }

        private string Personalize(string userName, string content)
        {
            // Use the provided userName as the persona prefix so the bot speaks using that name.
            if (string.IsNullOrWhiteSpace(userName))
                return $"Here is what i found: {content}";
            return $"{userName} here is what i found: {content}";
        }
    }
}

