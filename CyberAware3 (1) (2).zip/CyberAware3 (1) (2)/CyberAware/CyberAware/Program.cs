﻿using System;

namespace CyberAware
{
    class Program
    {
        // Console entrypoint from Part 1 is preserved here as a reference but is not used by the WPF application.
        // To run the original console version, change the project OutputType back to Exe and remove the WPF App.xaml startup.
        /*
        static void Main(string[] args)
        {
            GreetingManager greetingManager = new GreetingManager();
            // Show greeting (includes playing audio) before asking for the user's name
            greetingManager.ShowGreeting();

            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("Please enter your name: ");
            Console.ResetColor();
            string userName = Console.ReadLine() ?? "User";

            Chatbot chatbot = new Chatbot(userName);
            chatbot.Start();
        }
        */
    }
}
