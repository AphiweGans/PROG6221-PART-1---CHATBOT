using System.Windows;

namespace CyberAware
{
    public partial class App : Application
    {
    }
}
