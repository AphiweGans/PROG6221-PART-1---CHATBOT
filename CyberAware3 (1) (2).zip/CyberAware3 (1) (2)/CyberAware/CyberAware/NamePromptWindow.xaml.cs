using System.Windows;

namespace CyberAware
{
    public partial class NamePromptWindow : Window
    {
        public string UserName { get; private set; } = string.Empty;

        public NamePromptWindow()
        {
            InitializeComponent();
        }

        private void Ok_Click(object sender, RoutedEventArgs e)
        {
            UserName = NameBox.Text?.Trim() ?? string.Empty;
            DialogResult = true;
            Close();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
